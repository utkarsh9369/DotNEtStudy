﻿using asp.nett.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Web.Services.Description;
using System.Windows.Forms;

namespace asp.nett
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        

        protected void Page_Load(object sender, EventArgs e)
        {

            
            
        }

        protected void btn_Click(object sender, EventArgs e)
        {
            //Student st=new Student();
            //st.FirstName=txtfirstname.Text;
            //st.LastName=txtlastname.Text;
            //st.FatherName=txtfathername.Text;
            //st.Address=txtaddress.Text;
            //st.Course=ddlcourse.SelectedValue;
            SqlConnection conn = new SqlConnection("Data source=LAPTOP-MGGOC6QP\\SQLEXPRESS ;initial catalog=studentresrecord;integrated security=true");
            conn.Open();
            SqlCommand cmd = new SqlCommand("insert into record" + "(FirstName,LastName,FatherName,Address,Course) values (@FirstName,@LastName,@FatherName,@Address,@Course)",conn);
            cmd.Parameters.AddWithValue("@FirstName", txtfirstname.Text);
            cmd.Parameters.AddWithValue("@LastName", txtlastname.Text);
            cmd.Parameters.AddWithValue("@FatherName", txtfathername.Text);
            cmd.Parameters.AddWithValue("@Address", txtaddress.Text);
            cmd.Parameters.AddWithValue("@Course", ddlcourse.SelectedValue);
           int add= cmd.ExecuteNonQuery();
            if(add > 0)
            {
                MessageBox.Show("Resistration Successfully");

            }
            else
            {
                MessageBox.Show(" Resistration Failed");
            }
            conn.Close();


            
        }
    }
}