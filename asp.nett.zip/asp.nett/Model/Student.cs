﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace asp.nett.Model
{
    public class Student
    {
        //private properties
        string _FirstName;
        string _LastName;
        string _FatherName;
        string _Address;
        string _Course;

        public string FirstName { get => _FirstName; set => _FirstName = value; }
        public string LastName { get => _LastName; set => _LastName = value; }
        public string FatherName { get => _FatherName; set => _FatherName = value; }
        public string Address { get => _Address; set => _Address = value; }
        public string Course { get => _Course; set => _Course = value; }

        public Student(string FirstName, string LastName, string FatherName, string Address, string Course)
        {
            this._FirstName=FirstName;
            this._LastName=LastName;
            this._FatherName=FatherName;
            this._Address=Address;
            this._Course=Course;

        }
        public Student()
        {
            

        }

    }
}