﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace asp.nett
{
    public partial class studentgrid : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                grd_SelectedIndexChanged(sender, e);
            }
        }

        protected void grd_SelectedIndexChanged(object sender, EventArgs e)
        {

            SqlConnection conn = new SqlConnection("Data source=LAPTOP-MGGOC6QP\\SQLEXPRESS ;initial catalog=studentresrecord;integrated security=true");
            
                conn.Open();
                SqlCommand cmd = new SqlCommand("select * from record",conn);
                SqlDataReader dr= cmd.ExecuteReader();
                if(dr.HasRows==true)
                {
                    grd.DataSource = dr;
                    grd.DataBind();
                }
                conn.Close();
            
        }
    }
}