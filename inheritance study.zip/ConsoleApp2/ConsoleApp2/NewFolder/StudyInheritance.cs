﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2.NewFolder
{
    internal partial class StudyInheritance
    {

        public partial class Vehicle
        {
            public virtual void Move()
            {
                Console.WriteLine("Duplicate");
            }


        }
        }
}
