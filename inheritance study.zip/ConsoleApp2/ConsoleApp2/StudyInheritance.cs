﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
     internal partial class StudyInheritance
    {

       public partial class Vehicle
        {
            int engineCapacity;
            public Vehicle(int engineCapacity)
            {
                this.engineCapacity = engineCapacity;
                Console.WriteLine("Vehicle constructor called " + engineCapacity);

            }
            public virtual void Move()
            {
                Console.WriteLine("Move Vehicle");
            }
        }

        public class AutoRickshaw : Vehicle
        {
            public AutoRickshaw(int a) : base(a)
            {
                Console.WriteLine(" AutoRickshaw Constructor called" + a);

            }
            public override void Move()
            {
                Console.WriteLine("Move AutoRickshaw");
            }
        }

    }
}
