﻿// See https://aka.ms/new-console-template for more information
using static ConsoleApp2.StudyInheritance;

Vehicle vh = new AutoRickshaw(2);
//vh.Move();


Console.ReadLine();
